package com.mytaxi.service.car.search.filter;

import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.EngineType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Fabricio on 26/02/2018.
 */


public class CriteriaFilterTest {

    CarDTO carDTO;
    List<CarDTO> carList;

    @Before
    public void init() {
        CarDTO carDTO = new CarDTO(1L, "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY, 2L);
        carList = new ArrayList<>();
        carList.add(carDTO);
    }

    @Test
    public void when_query_manufacturer_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("manufacturer");
        Assert.assertEquals(criteria.search(carList, "FIAT").size(), 1);
    }

    @Test
    public void when_query_convertible_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("convertible");
        Assert.assertEquals(criteria.search(carList, Boolean.FALSE).size(), 1);
    }

    @Test
    public void when_query_driverid_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("driverId");
        Assert.assertEquals(criteria.search(carList, 2L).size(), 1);
    }


    @Test
    public void when_query_license_plate_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("licensePlate");
        Assert.assertEquals(criteria.search(carList, "QWER123").size(), 1);
    }

    @Test
    public void when_query_rating_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("rating");
        Assert.assertEquals(criteria.search(carList, 5).size(), 1);
    }

    @Test
    public void when_query_seat_count_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("seatCount");
        Assert.assertEquals(criteria.search(carList, 4).size(), 1);
    }

    @Test
    public void when_query_car_status_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("status");
        Assert.assertEquals(criteria.search(carList, CarStatus.BUSY).size(), 1);
    }

    @Test
    public void when_query_engine_type_return_object() {

        Criteria criteria = CriteriaFactory.getSearchCriteria("engineType");
        Assert.assertEquals(criteria.search(carList, EngineType.ELECTRICAL).size(), 1);
    }
}
