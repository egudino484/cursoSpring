package com.mytaxi.controller.mapper;

import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.EngineType;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class CarMapperTest
{
    CarDTO carDTO;
    List<CarDTO> carDTOList;
    CarDO carDO;
    List<CarDO> carDOList;

    @Before
    public void setUp() throws Exception {
        carDTO = new CarDTO(1L, "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY, 2L);
        carDTOList = new ArrayList<>();
        carDTOList.add(carDTO);

        carDO = new CarDO( "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY);

        carDOList = new ArrayList<>();
        carDOList.add(carDO);
    }

    @Test
    public void when_make_dto_return_dto() throws Exception {
       Assert.assertEquals(CarMapper.makeCarDO(carDTO).getManufacturer(),carDO.getManufacturer());
    }

    @Test
    public void when_make_do_return_do() throws Exception {
        Assert.assertEquals(CarMapper.makeCarDO(carDTO).getManufacturer(),carDTO.getManufacturer());
    }

    @Test
    public void when_make_list_return_list_carDTO() throws Exception {
        Assert.assertEquals(CarMapper.makeCarDTOList(carDOList).size(),1);
    }


}
