package com.mytaxi.controller.mapper;

import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.datatransferobject.DriverDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import javax.validation.constraints.Null;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;


public class DriverMapperTest
{

    DriverDTO driverDTO;
    List<DriverDTO> driverDTOList;
    DriverDO driverDO;
    List<DriverDO> driverDOList;

    @Before
    public void setUp() throws Exception {
        driverDTO = new DriverDTO(1L,"driver01", "driver01ppw", null);
        driverDTOList = new ArrayList<>();
        driverDTOList.add(driverDTO);

        driverDO = new DriverDO( "driver01", "driver01ppw");

        driverDOList = new ArrayList<>();
        driverDOList.add(driverDO);
    }

    @Test
    public void when_make_dto_return_dto() throws Exception {
        Assert.assertEquals(DriverMapper.makeDriverDTO(driverDO).getUsername(),driverDTO.getUsername());
    }

    @Test
    public void when_make_do_return_do() throws Exception {
        Assert.assertEquals(DriverMapper.makeDriverDO(driverDTO).getUsername(),driverDO.getUsername());
    }

    @Test
    public void when_make_list_return_list_carDTO() throws Exception {
        Assert.assertEquals(DriverMapper.makeDriverDTOList(driverDOList).size(),1);
    }

}
