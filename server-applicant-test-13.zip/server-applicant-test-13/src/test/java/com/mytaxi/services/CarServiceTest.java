package com.mytaxi.services;

import com.mytaxi.dataaccessobject.CarRepository;
import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.domainvalue.FilterSearchOperations;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.service.car.CarService;
import com.mytaxi.service.car.DefaultCarService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.lang.Long.*;
import static org.mockito.Mockito.*;

/**
 * Test class for CarService
 */

public class CarServiceTest {



    private CarService carService;


    private CarRepository carRepositoryMock;


    CarDO carDO;
    List<CarDO> carDOList;
    CarDTO carDTO;
    List<CarDTO> carDTOList;

    @Before
    public void setUp() throws Exception {
        carRepositoryMock = Mockito.mock(CarRepository.class);
        carService = new DefaultCarService(carRepositoryMock);


        carDO = new CarDO( "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY);

        carDOList = new ArrayList<>();
        carDOList.add(carDO);

        carDTO = new CarDTO(1L, "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY, 2L);
        carDTOList = new ArrayList<>();
        carDTOList.add(carDTO);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_search_return_object_id() throws EntityNotFoundException {
        when(carService.find(1L)).thenReturn(carDO);
        Assert.assertEquals(carDO.getId(), java.util.Optional.of(1L));
    }

    @Test
    public void when_search_return_object_list() throws EntityNotFoundException {
        when(carService.find(CarStatus.AVAILABLE)).thenReturn(carDOList);
        Assert.assertEquals(carDOList.size(), 1);
    }

    @Test
    public void when_search_return_not_deleted_object_list() throws EntityNotFoundException {
        when(carService.find(Boolean.FALSE)).thenReturn(carDOList);
        Assert.assertEquals(carDOList.get(0).getDeleted(), Boolean.FALSE);
    }

    @Test
    public void when_create_return_object_list() throws ConstraintsViolationException {
        when(carService.create(carDO)).thenReturn(carDO);
        CarDO car = carService.create(carDO);
        Assert.assertNotNull(carDO);
    }

    @Test
    public void when_search_and_filters_return_object_list() throws EntityNotFoundException {
        CarDTO carSearchDTO = new CarDTO();
        carSearchDTO.setManufacturer("FIAT");
        when(carService.find(Boolean.FALSE)).thenReturn(carDOList);
        when(carService.findByFilters(carSearchDTO, FilterSearchOperations.AND)).thenReturn(carDTOList);
        Assert.assertNotNull(carDOList);
    }

    @Test
    public void when_search_or_filters_return_object_list() throws EntityNotFoundException {
        CarDTO carSearchDTO = new CarDTO();
        carSearchDTO.setManufacturer("FIAT");
        when(carService.find(Boolean.FALSE)).thenReturn(carDOList);
        when(carService.findByFilters(carSearchDTO, FilterSearchOperations.OR)).thenReturn(carDTOList);
        Assert.assertNotNull(carDOList);
    }

    @Test(expected = EntityNotFoundException.class)
    public void when_search_or_filters_return_object_list_not_found() throws EntityNotFoundException {
        CarDTO carSearchDTO = new CarDTO();
        carSearchDTO.setManufacturer("FIAT");
        when(carService.findByFilters(carSearchDTO, FilterSearchOperations.OR)).thenReturn(carDTOList);
        Assert.assertNotNull(carDOList);
    }

    @Test
    public void when_delete_car_not_found_throw_exception() throws EntityNotFoundException {
        CarDTO carSearchDTO = mock(CarDTO.class);
        CarService service = mock(DefaultCarService.class);
        carSearchDTO = carDTO;
        doThrow(EntityNotFoundException.class).when(service).delete(carDTO.getId());


    }

    @Test
    public void when_update_status_car_not_found_throw_exception() throws EntityNotFoundException {
        CarDTO carSearchDTO = mock(CarDTO.class);
        CarService service = mock(DefaultCarService.class);
        carSearchDTO = carDTO;
        doThrow(EntityNotFoundException.class).when(service).updateCarStatus(carSearchDTO.getId(), CarStatus.BUSY);


    }

}
