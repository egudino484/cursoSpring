package com.mytaxi.controllers;

import com.mytaxi.config.User;
import com.mytaxi.controller.CarController;
import com.mytaxi.controller.mapper.CarMapper;
import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.service.car.CarService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.json.JsonContent;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.mockito.BDDMockito.willReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;

/**
 * Created by Fabricio on 26/02/2018.
 */
@RunWith(SpringRunner.class)
@WebMvcTest(value = CarController.class, secure = false)
public class CarControllerTest {


    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CarService carServiceMock;



    CarDTO carDTO;
    List<CarDTO> carDTOList;
    CarDO carDO;
    List<CarDO> carDOList;

    @Before
    public void setUp() throws Exception {
        carDTO = new CarDTO(1L, "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY, 2L);
        carDTOList = new ArrayList<>();
        carDTOList.add(carDTO);

        carDO = new CarDO( "FIAT", "QWER123", 4, Boolean.FALSE, 5,
                EngineType.ELECTRICAL, CarStatus.BUSY);

        carDOList = new ArrayList<>();
        carDOList.add(carDO);
    }


    @Test
    public void when_search_car_return_object()
            throws Exception {
        MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
        parameters.set("username", "driver01");
        parameters.set("password", "driver01pw");
        when(carServiceMock.find(1L)).thenReturn(carDO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/v1/cars/1").accept(
                MediaType.APPLICATION_JSON).params(parameters);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        System.out.println("Rest response "  + result.getResponse().toString());
        Assert.assertNotNull(result);

    }

    @Test
    public void when_create_car_return_object()
            throws Exception {

        String jsonContent = "{\n" +
                "  \"convertible\": true,\n" +
                "  \"driverId\": 0,\n" +
                "  \"engineType\": \"GASOLINE\",\n" +
                "  \"id\": 0,\n" +
                "  \"licensePlate\": \"qaaq1211\",\n" +
                "  \"manufacturer\": \"NISSAN\",\n" +
                "  \"rating\": 4,\n" +
                "  \"seatCount\": 4,\n" +
                "  \"status\": \"BUSY\"\n" +
                "}";
        Mockito.when(
                carServiceMock.create(Mockito.any(CarDO.class))).thenReturn(carDO);
       // RequestBuilder bu = preparePostForRegisterForm("username","driver02","password","driver02pw");

        MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
        parameters.set("username", "driver01");
        parameters.set("password", "driver01pw");

        RequestBuilder requestBuilder =
                post("/v1/cars")
                .params(parameters)
                .accept(MediaType.APPLICATION_JSON)
                .content(jsonContent)
                .contentType(MediaType.APPLICATION_JSON);

        print();
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());

    }

    @Test
    public void when_delete_object() throws Exception {

        MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
        parameters.set("username", "driver01");
        parameters.set("password", "driver01pw");
        when(carServiceMock.find(1L)).thenReturn(carDO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/v1/cars/1").accept(
                MediaType.APPLICATION_JSON).params(parameters);
        print();
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void when_update_object() throws Exception {

        MultiValueMap<String, String> parameters = new LinkedMultiValueMap<>();
        parameters.set("username", "driver01");
        parameters.set("password", "driver01pw");
        parameters.set("carStatus", "AVAILABLE");
        when(carServiceMock.find(1L)).thenReturn(carDO);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/v1/cars/2").accept(
                MediaType.APPLICATION_JSON).params(parameters);
        print();
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }

}
