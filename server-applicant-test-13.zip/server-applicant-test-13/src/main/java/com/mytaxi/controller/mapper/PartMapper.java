package com.mytaxi.controller.mapper;

import com.mytaxi.datatransferobject.DriverDTO;
import com.mytaxi.datatransferobject.PartDTO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainobject.PartDO;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class PartMapper
{
    public static PartDO makePartDO(PartDTO partDTO)
    {
        return new PartDO( partDTO.getDescription(), partDTO.getPrice(), partDTO.getMaterial());
    }

//TODO cambiar a partdo y partdto 
    public static PartDTO makePartDTO(PartDTO partDTO)
    {
    	
    	PartDTO.PartDTOBuilder partDTOBuilder1 = PartDTO.newBuilder()
                .setId(partDTO.getId())
                .setDescription(partDTO.getDescription())
                .setMaterial(partDTO.getMaterial())
                .setPrice(partDTO.getPrice())		
                ;
                


    	/*PartDTO.DriverDTOBuilder driverDTOBuilder1 = PartDTO.newBuilder()
                .setId(driverDO.getId())
                .setDescription(driverDO.getDescription())
                ;*/
    	
       /* PartDTO.DriverDTOBuilder driverDTOBuilder2 = PartDTO.newBuilder()
            .setId(driverDO.getId())
            .setDescription(driverDO.getDescription())
            .setPrice(driverDO.getPrice());*/



        return partDTOBuilder1.createPartDTO();
    }


    private static PartDTO setId(Long id) {
	// TODO Auto-generated method stub
	return null;
}

    public static List<PartDTO> makeDriverDTOList(Collection<PartDO> parts)
    {
        return parts.stream()
            .map(PartMapper::makePartDTO)
            .collect(Collectors.toList());
    }
}
