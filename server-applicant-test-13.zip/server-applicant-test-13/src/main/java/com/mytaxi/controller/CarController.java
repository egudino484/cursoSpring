package com.mytaxi.controller;

import com.mytaxi.controller.mapper.CarMapper;
import com.mytaxi.controller.mapper.DriverMapper;
import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.datatransferobject.DriverDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.EngineType;
import com.mytaxi.domainvalue.FilterSearchOperations;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.service.car.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Routes requests concerning resource Car
 */

@RestController
@RequestMapping("v1/cars")
public class CarController {

    private final CarService carService;

    @Autowired
    public CarController(final CarService carService)
    {
        this.carService = carService;
    }

    @GetMapping("/{carId}")
    public CarDTO getCar(@Valid @PathVariable long carId) throws EntityNotFoundException {
        return CarMapper.makeCarDTO(carService.find(carId));
    }


    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CarDTO createCar(@Valid @RequestBody CarDTO carDTO) throws ConstraintsViolationException
    {
        CarDO carDO = CarMapper.makeCarDO(carDTO);
        return CarMapper.makeCarDTO(carService.create(carDO));
    }

    @PutMapping("/{carId}")
    public void updateStatus(
            @Valid @PathVariable long carId, @RequestParam CarStatus carStatus)
            throws ConstraintsViolationException, EntityNotFoundException
    {
        carService.updateCarStatus(carId, carStatus);
    }

    @DeleteMapping("/{carId}")
    public void deleteCar(@Valid @PathVariable long carId) throws EntityNotFoundException
    {
        carService.delete(carId);
    }

    @GetMapping
    public List<CarDTO> findByFilters(@RequestParam FilterSearchOperations searchOperation, @RequestParam(required = false) String manufacturer, @RequestParam(required = false) String licensePlate, @RequestParam(required = false) Integer seatCount, @RequestParam(required = false) Boolean convertible, @RequestParam(required = false) Integer rating, @RequestParam(required = false) EngineType engineType, @RequestParam(required = false) CarStatus status , @RequestParam(required = false) Long driverId) throws EntityNotFoundException {
        CarDTO carDTO = new CarDTO(0L,  manufacturer,  licensePlate,  seatCount,  convertible,  rating,
                 engineType,  status,  driverId);
        return carService.findByFilters(carDTO, searchOperation);
    }





}
