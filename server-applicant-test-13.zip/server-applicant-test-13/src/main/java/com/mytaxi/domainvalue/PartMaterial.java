package com.mytaxi.domainvalue;

public enum PartMaterial {

	    PLASTICO, METAL,CAUCHO, FIBRA
	

}
