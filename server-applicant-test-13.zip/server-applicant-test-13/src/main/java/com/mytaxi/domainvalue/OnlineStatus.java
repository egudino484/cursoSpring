package com.mytaxi.domainvalue;

public enum OnlineStatus
{
    ONLINE, OFFLINE
}
