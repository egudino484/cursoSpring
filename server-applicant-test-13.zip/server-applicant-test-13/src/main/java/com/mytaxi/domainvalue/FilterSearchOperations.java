package com.mytaxi.domainvalue;

/**
 * Created by Fabricio on 22/02/2018.
 */
public enum FilterSearchOperations {
    AND,OR
}
