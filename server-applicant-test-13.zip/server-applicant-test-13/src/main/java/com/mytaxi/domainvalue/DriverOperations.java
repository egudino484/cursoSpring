package com.mytaxi.domainvalue;

/**
 * Created by Fabricio on 22/02/2018.
 */
public enum DriverOperations {
    SELECT_CAR,DESELECT_CAR
}
