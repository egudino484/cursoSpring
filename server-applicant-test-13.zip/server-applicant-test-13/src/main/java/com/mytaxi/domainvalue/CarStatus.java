package com.mytaxi.domainvalue;

public enum CarStatus {

    AVAILABLE, BUSY, OUTOFSERVICE
}
