package com.mytaxi.domainvalue;

/**
 * Created by Fabricio on 21/02/2018.
 */
public enum EngineType {
    GASOLINE, ELECTRICAL, HYBRID, DIESEL
}
