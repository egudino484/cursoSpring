package com.mytaxi.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Created by Fabricio on 22/02/2018.
 */
@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Driver status is not ONLINE. Login again or contact support")
public class DriverOnlineException extends Throwable {

    static final long serialVersionUID = -3387516993334229948L;

    public DriverOnlineException(String message) {
        super(message);
    }
}
