package com.mytaxi.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Created by Fabricio on 23/02/2018.
 */
@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "Car is out of order. Please choose another one")
public class CarOutOfServiceException extends Throwable {
    static final long serialVersionUID = -3387516993334229948L;

    public CarOutOfServiceException(String message) {
        super(message);
    }
}
