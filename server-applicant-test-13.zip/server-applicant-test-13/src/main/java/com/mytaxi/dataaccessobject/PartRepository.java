package com.mytaxi.dataaccessobject;

import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainobject.PartDO;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.domainvalue.PartMaterial;

import java.util.List;
import org.springframework.data.repository.CrudRepository;

/**
 * Database Access Object for driver table.
 * <p/>
 */
public interface PartRepository extends CrudRepository<PartDO, Long>
{

    List<PartDO> findByPartMaterial(PartMaterial material);
    PartDO findById(Long id);
}
