package com.mytaxi.dataaccessobject;

import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.OnlineStatus;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Database Access Object for cars table.
 * <p/>
 */
@Component
public interface CarRepository extends CrudRepository<CarDO, Long>
{

    List<CarDO> findByStatus(CarStatus carStatus);

    List<CarDO> findByDeleted(Boolean deleted);
}
