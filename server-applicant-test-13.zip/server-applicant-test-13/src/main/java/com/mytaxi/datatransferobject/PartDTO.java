package com.mytaxi.datatransferobject;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.PartMaterial;

import javax.validation.constraints.NotNull;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class PartDTO
{
    @JsonIgnore
    private Long id;

    @NotNull(message = "description can not be null!")
    private String description;

    @NotNull(message = "price can not be null!")
    private double price;

    private PartMaterial material;


    public PartDTO()
    {
    }


    


    public PartDTO( String description, double price, PartMaterial material) {
		super();
	
		this.description = description;
		this.price = price;
		this.material = material;
	}





	public static PartDTOBuilder newBuilder()
    {
        return new PartDTOBuilder();
    }


    @JsonProperty
    public Long getId()
    {
        return id;
    }


    

    public String getDescription() {
		return description;
	}





	public void setDescription(String description) {
		this.description = description;
	}





	public double getPrice() {
		return price;
	}





	public void setPrice(double price) {
		this.price = price;
	}





	public PartMaterial getMaterial() {
		return material;
	}





	public void setMaterial(PartMaterial material) {
		this.material = material;
	}





	public void setId(Long id) {
		this.id = id;
	}




	public static class PartDTOBuilder
    {
        private Long id;
        private String description;
        private double price;
        private PartMaterial material;


        public PartDTOBuilder setId(Long id)
        {
            this.id = id;
            return this;
        }




        public String getDescription() {
			return description;
		}




		public PartDTOBuilder setDescription(String description) {
			this.description = description;
			 return this;
		}




		public double getPrice() {
			return price;
		}




		public PartDTOBuilder setPrice(double price) {
			this.price = price;
			 return this;
		}




		public PartMaterial getMaterial() {
			return material;
		}




		public PartDTOBuilder setMaterial(PartMaterial material) {
			this.material = material;
			 return this;
		}




		public PartDTO createPartDTO()
        {
            return new PartDTO( description, price, material);
        }

    }
}
