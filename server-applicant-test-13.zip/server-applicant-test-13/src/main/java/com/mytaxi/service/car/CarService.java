package com.mytaxi.service.car;

import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.DriverOperations;
import com.mytaxi.domainvalue.FilterSearchOperations;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * Created by Fabricio on 21/02/2018.
 */
public interface CarService {

    CarDO find(Long carId) throws EntityNotFoundException;

    CarDO create(CarDO carDO) throws ConstraintsViolationException;

    void delete(Long carId) throws EntityNotFoundException;

    void updateCarStatus(long carId, CarStatus status) throws EntityNotFoundException;

    List<CarDO> find(CarStatus carStatus);

    List<CarDO> find(Boolean deleted);

    List<CarDTO> findByFilters(CarDTO carDTO, FilterSearchOperations searchOperation) throws EntityNotFoundException;
}
