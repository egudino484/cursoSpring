package com.mytaxi.service.car.search.filter;

import com.mytaxi.datatransferobject.CarDTO;

import java.util.List;

/**
 * Created by Fabricio on 23/02/2018.
 */
public interface Criteria {
    List<CarDTO> search(List<CarDTO> carList, Object searchItem);
}
