package com.mytaxi.service.part;

import com.mytaxi.dataaccessobject.DriverRepository;
import com.mytaxi.dataaccessobject.PartRepository;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainobject.PartDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.DriverOperations;
import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.domainvalue.PartMaterial;
import com.mytaxi.exception.*;

import java.util.List;

import com.mytaxi.service.car.CarService;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service to encapsulate the link between DAO and controller and to have business logic for some driver specific things.
 * <p/>
 */
@Service
public class DefaultPartService implements PartService
{

    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(DefaultPartService.class);

    private final PartRepository partRepository;

    private final PartService partService;


    public DefaultPartService(final PartRepository driverRepository, PartService carService)
    {
        this.partRepository = driverRepository;
        this.partService = carService;
    }


    /**
     * Selects a driver by id.
     *
     * @param driverId
     * @return found driver
     * @throws EntityNotFoundException if no driver with the given id was found.
     */
    @Override
    public PartDO find(Long driverId) throws EntityNotFoundException
    {
        return findPart(driverId);
    }
    private PartDO findPart(Long driverId) throws EntityNotFoundException
    {
    	PartDO driverDO = partRepository.findOne(driverId);
        if (driverDO == null)
        {
            throw new EntityNotFoundException("Could not find entity with id: " + driverId);
        }
        return driverDO;
    }


    /**
     * Creates a new driver.
     *
     * @param driverDO
     * @return
     * @throws ConstraintsViolationException if a driver already exists with the given username, ... .
     */
    @Override
    public PartDO create(PartDO driverDO) throws ConstraintsViolationException
    {
    	PartDO driver;
        try
        {
            driver = partRepository.save(driverDO);
        }
        catch (DataIntegrityViolationException e)
        {
            LOG.warn("Some constraints are thrown due to driver creation", e);
            throw new ConstraintsViolationException(e.getMessage());
        }
        return driver;
    }





    /**
     * Update the location for a driver.
     *
     * @param driverId
     * @param longitude
     * @param latitude
     * @throws EntityNotFoundException
     */
    @Transactional
    @Override
	public void updatePrice(long driverId, double precio) throws EntityNotFoundException {
    
        PartDO driverDO = find(driverId);
        driverDO.setPrice(precio);
    }
    

  



  













	@Override
	public List<PartDO> find(PartMaterial material) {
		// TODO Auto-generated method stub
        return partRepository.findByPartMaterial(material);

	}


	@Override
	public void delete(Long driverId) throws EntityNotFoundException {
		// TODO Auto-generated method stub
		
	}

}
