package com.mytaxi.service.part;

import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainobject.PartDO;
import com.mytaxi.domainvalue.DriverOperations;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.domainvalue.PartMaterial;
import com.mytaxi.exception.*;

import java.util.List;

public interface PartService
{

    PartDO find(Long driverId) throws EntityNotFoundException;

    PartDO create(PartDO driverDO) throws ConstraintsViolationException;

    void delete(Long driverId) throws EntityNotFoundException;

    void updatePrice(long driverId, double precio) throws EntityNotFoundException;

    List<PartDO> find(PartMaterial material);


}
