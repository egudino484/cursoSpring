package com.mytaxi.service.driver;

import com.mytaxi.dataaccessobject.DriverRepository;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainobject.DriverDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.DriverOperations;
import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.exception.*;

import java.util.List;

import com.mytaxi.service.car.CarService;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service to encapsulate the link between DAO and controller and to have business logic for some driver specific things.
 * <p/>
 */
@Service
public class DefaultDriverService implements DriverService
{

    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(DefaultDriverService.class);

    private final DriverRepository driverRepository;

    private final CarService carService;


    public DefaultDriverService(final DriverRepository driverRepository, CarService carService)
    {
        this.driverRepository = driverRepository;
        this.carService = carService;
    }


    /**
     * Selects a driver by id.
     *
     * @param driverId
     * @return found driver
     * @throws EntityNotFoundException if no driver with the given id was found.
     */
    @Override
    public DriverDO find(Long driverId) throws EntityNotFoundException
    {
        return findDriverChecked(driverId);
    }


    /**
     * Creates a new driver.
     *
     * @param driverDO
     * @return
     * @throws ConstraintsViolationException if a driver already exists with the given username, ... .
     */
    @Override
    public DriverDO create(DriverDO driverDO) throws ConstraintsViolationException
    {
        DriverDO driver;
        try
        {
            driver = driverRepository.save(driverDO);
        }
        catch (DataIntegrityViolationException e)
        {
            LOG.warn("Some constraints are thrown due to driver creation", e);
            throw new ConstraintsViolationException(e.getMessage());
        }
        return driver;
    }


    /**
     * Deletes an existing driver by id.
     *
     * @param driverId
     * @throws EntityNotFoundException if no driver with the given id was found.
     */
    @Override
    @Transactional
    public void delete(Long driverId) throws EntityNotFoundException
    {
        DriverDO driverDO = findDriverChecked(driverId);
        driverDO.setDeleted(true);
    }


    /**
     * Update the location for a driver.
     *
     * @param driverId
     * @param longitude
     * @param latitude
     * @throws EntityNotFoundException
     */
    @Transactional
    @Override
    public void updateLocation(long driverId, double longitude, double latitude) throws EntityNotFoundException
    {
        DriverDO driverDO = findDriverChecked(driverId);
        driverDO.setCoordinate(new GeoCoordinate(latitude, longitude));
    }


    /**
     * Find all drivers by online state.
     *
     * @param onlineStatus
     */
    @Override
    public List<DriverDO> find(OnlineStatus onlineStatus)
    {
        return driverRepository.findByOnlineStatus(onlineStatus);
    }


    private DriverDO findDriverChecked(Long driverId) throws EntityNotFoundException
    {
        DriverDO driverDO = driverRepository.findOne(driverId);
        if (driverDO == null)
        {
            throw new EntityNotFoundException("Could not find entity with id: " + driverId);
        }
        return driverDO;
    }


    @Transactional
    public void updateCarAvailability(Long driverId, Long carId, DriverOperations operation)
            throws EntityNotFoundException, DriverOnlineException, CarAlreadyInUseException, CarOutOfServiceException, CarSelectionException {
        DriverDO driverDO = findDriverChecked(driverId);
        checkDriverOnline(driverDO.getOnlineStatus());
        CarDO carDO = carService.find(carId);

            if(DriverOperations.SELECT_CAR.equals(operation)) {
                selectCar(driverDO, carDO);
            } else if(DriverOperations.DESELECT_CAR.equals(operation)) {
                deselectCar(driverDO, carDO);
            }
    }

    @Transactional
    private void selectCar(DriverDO driverDO, CarDO carDO) throws CarAlreadyInUseException, CarOutOfServiceException {
        if(carDO.getStatus().equals(CarStatus.AVAILABLE)) {
            carDO.setStatus(CarStatus.BUSY);
            carDO.setDriverDO(driverDO);
            driverDO.setCarDO(carDO);
        } else if(carDO.getStatus().equals(CarStatus.BUSY)) {
            throw new CarAlreadyInUseException("Car selected is already in use. Please choose another one");
        } else if(carDO.getStatus().equals(CarStatus.OUTOFSERVICE)) {
            throw new CarOutOfServiceException("Car is out of service");
        }
    }

    @Transactional
    private void deselectCar(DriverDO driverDO, CarDO carDO) throws CarAlreadyInUseException, CarOutOfServiceException, CarSelectionException {
        if(carDO.getStatus().equals(CarStatus.BUSY)) {
            carDO.setStatus(CarStatus.AVAILABLE);
            carDO.setDriverDO(null);
            driverDO.setCarDO(null);
        } else if(carDO.getStatus().equals(CarStatus.AVAILABLE)) {
            throw new CarSelectionException("Car selected is idle and cannot be deselected");
        } else if(carDO.getStatus().equals(CarStatus.OUTOFSERVICE)){
            carDO.setDriverDO(null);
            driverDO.setCarDO(null);
        }
    }

    private void checkDriverOnline(OnlineStatus onlineStatus) throws DriverOnlineException {
       if(onlineStatus.compareTo(OnlineStatus.ONLINE) != 0) {
           throw new DriverOnlineException("Driver status is not ONLINE. Log in again or contact technical support");
       }
    }

}
