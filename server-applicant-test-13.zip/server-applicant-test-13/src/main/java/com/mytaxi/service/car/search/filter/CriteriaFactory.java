package com.mytaxi.service.car.search.filter;

/**
 * Created by Fabricio on 24/02/2018.
 */
public class CriteriaFactory {

    /**
     * Returns constructor based on search criteria
     * @param criteria
     * @return
     */
        public static Criteria getSearchCriteria(String criteria)
        {
            if ( criteria.equals("manufacturer") ) {
                return new CriteriaManufacturer();
            } else if ( criteria.equals("licensePlate")) {
                return new CriteriaLicensePlate();
            } else if ( criteria.equals("convertible") ) {
                return new CriteriaConvertible();
            } else if ( criteria.equals("seatCount") ) {
                return new CriteriaSeatCount();
            } else if ( criteria.equals("rating") ) {
                return new CriteriaRating();
            } else if ( criteria.equals("engineType") ) {
                return new CriteriaEngineType();
            } else if ( criteria.equals("status") ) {
                return new CriteriaStatus();
            } else if ( criteria.equals("driverId") ) {
                return new CriteriaDriverId();
            }


            return null;
        }


}
