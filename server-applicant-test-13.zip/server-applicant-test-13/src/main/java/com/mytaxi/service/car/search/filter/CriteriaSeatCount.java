package com.mytaxi.service.car.search.filter;

import com.mytaxi.datatransferobject.CarDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Fabricio on 23/02/2018.
 */
public class CriteriaSeatCount implements Criteria {

    /***
     * Performs search based on a criteria
     * @param carList
     * @param searchItem
     * @return
     */
    @Override
    public List<CarDTO> search(List<CarDTO> carList, Object searchItem) {
        List<CarDTO> cars = new ArrayList<CarDTO>();

        for (CarDTO carDTO : carList) {
            if(carDTO.getSeatCount().compareTo((Integer) searchItem) == 0){
                cars.add(carDTO);
            }
        }
        return cars;
    }


}
