package com.mytaxi.service.car;

import com.mytaxi.controller.mapper.CarMapper;
import com.mytaxi.dataaccessobject.CarRepository;
import com.mytaxi.datatransferobject.CarDTO;
import com.mytaxi.domainobject.CarDO;
import com.mytaxi.domainvalue.CarStatus;
import com.mytaxi.domainvalue.DriverOperations;
import com.mytaxi.domainvalue.FilterSearchOperations;
import com.mytaxi.exception.ConstraintsViolationException;
import com.mytaxi.exception.EntityNotFoundException;
import com.mytaxi.service.car.search.filter.Criteria;
import com.mytaxi.service.car.search.filter.CriteriaFactory;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Service for car operations
 */
@Service
public class DefaultCarService implements CarService {

    private static org.slf4j.Logger LOG = LoggerFactory.getLogger(DefaultCarService.class);

    private final CarRepository carRepository;

    public DefaultCarService(CarRepository carRepository) {
        this.carRepository = carRepository;
    }


    @Override
    public CarDO find(Long carId) throws EntityNotFoundException {

        return findCarChecked(carId);
    }

    @Override
    public CarDO create(CarDO carDO) throws ConstraintsViolationException {

        CarDO car;

        try
        {
            car = carRepository.save(carDO);
        }
        catch (DataIntegrityViolationException e)
        {
            LOG.warn("Some constraints are thrown due to car creation", e);
            throw new ConstraintsViolationException(e.getMessage());
        }
        return car;
    }

    @Override
    @Transactional
    public void delete(Long carId) throws EntityNotFoundException {
        CarDO carDO = findCarChecked(carId);
        carDO.setDeleted(true);
    }

    @Override
    @Transactional
    public void updateCarStatus(long carId, CarStatus status) throws EntityNotFoundException {
        CarDO carDO = findCarChecked(carId);
        carDO.setStatus(status);
    }

    @Override
    public List<CarDO> find(CarStatus carStatus) {
        return carRepository.findByStatus(carStatus);
    }

    @Override
    public List<CarDO> find(Boolean deleted) {
        return carRepository.findByDeleted(deleted);
    }


    public List<CarDTO> findByFilters(CarDTO carDTO, FilterSearchOperations searchOperation) throws EntityNotFoundException {
        Map<String,Object> validParameters = getValidParameters(carDTO);
        List<CarDO> allCars = find(Boolean.FALSE);
        List<CarDTO> resultingCars = new ArrayList<>();
        Set<CarDTO> resultSet = new HashSet<>();
        IntegerProperty counter = new SimpleIntegerProperty(0);

        if (!allCars.isEmpty()) {
            List<CarDTO> finalCarDTOList = CarMapper.makeCarDTOList(allCars);

            validParameters.forEach((String key, Object value) -> {
                System.out.println("Key : " + key + " Value : " + value);
                Criteria criteria = CriteriaFactory.getSearchCriteria(key);
                List<CarDTO> search = criteria.search(finalCarDTOList, value);
                if (searchOperation.equals(FilterSearchOperations.AND) && !search.isEmpty()) {
                    if(counter.get() == 0) {
                        resultSet.addAll(search);
                    } else {
                        resultSet.retainAll(search);
                    }

                } else if(searchOperation.equals(FilterSearchOperations.OR) && !search.isEmpty()) {
                        resultSet.addAll(search);
                }
                counter.set(counter.get() + 1);
            });

            //Invoke method to do the filtering
            resultingCars.addAll(resultSet);

        } else {
          throw new EntityNotFoundException("Could not find any cars");
        }
        return resultingCars;
    }

    private CarDO findCarChecked(Long carId) throws EntityNotFoundException {
        CarDO CarDO = carRepository.findOne(carId);
        if (null == CarDO) {
            throw new EntityNotFoundException("Could not find entity with id: " + carId);
        }
        return CarDO;
    }


    private Map<String,Object> getValidParameters(CarDTO carDTO) {
        Map<String,Object> validParameters = new HashMap<>();
        if(null != carDTO.getManufacturer()) {
            validParameters.put("manufacturer",carDTO.getManufacturer());
        }
        if(null != carDTO.getLicensePlate()) {
            validParameters.put("licensePlate",carDTO.getLicensePlate());
        }
        if(null != carDTO.getSeatCount()) {
            validParameters.put("seatCount",carDTO.getSeatCount());
        }
        if(null != carDTO.getConvertible()) {
            validParameters.put("convertible",carDTO.getConvertible());
        }
        if(null != carDTO.getRating()) {
            validParameters.put("rating",carDTO.getRating());
        }
        if(null != carDTO.getEngineType()) {
            validParameters.put("engineType",carDTO.getEngineType());
        }
        if(null != carDTO.getStatus()) {
            validParameters.put("status",carDTO.getStatus());
        }
        if(null != carDTO.getDriverId()) {
            validParameters.put("driverId",carDTO.getDriverId());
        }
        return validParameters;
    }

}
