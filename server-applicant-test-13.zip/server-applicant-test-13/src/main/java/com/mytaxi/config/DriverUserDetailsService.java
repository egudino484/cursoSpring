package com.mytaxi.config;

import com.mytaxi.dataaccessobject.DriverRepository;
import com.mytaxi.domainobject.DriverDO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 *  Implementation of the UserDetails Service
 */
@Service
public class DriverUserDetailsService implements UserDetailsService {

    @Autowired
    DriverRepository driverRepository;

    /**
     * Loads users by name for authentication purposes
     * @param username
     * @return
     * @throws UsernameNotFoundException  when user is not found
     */
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        DriverDO driverDO = driverRepository.findByUsername(username);
        User user = new User(driverDO.getId(),driverDO.getUsername(), driverDO.getPassword());
        if (user == null) {
            throw new UsernameNotFoundException(username);
        }
        return new UserPrincipal(user);
    }

}
