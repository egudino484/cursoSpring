package com.mytaxi.domainobject;

import com.mytaxi.domainvalue.GeoCoordinate;
import com.mytaxi.domainvalue.OnlineStatus;
import com.mytaxi.domainvalue.PartMaterial;

import java.time.ZonedDateTime;
import javax.persistence.*;
import javax.validation.constraints.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(
    name = "part"
)
public class PartDO
{

    @Id
    @GeneratedValue
    private Long id;



    @Column(nullable = false)
    @NotNull(message = "description can not be null!")
    private String description;


    @Column(nullable = false)
    private double price ;

   

    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private PartMaterial material;



    private PartDO()
    {
    }


 

    public Long getId()
    {
        return id;
    }


    public void setId(Long id)
    {
        this.id = id;
    }




	public String getDescription() {
		return description;
	}




	public void setDescription(String description) {
		this.description = description;
	}




	


	public double getPrice() {
		return price;
	}




	public void setPrice(double price) {
		this.price = price;
	}




	public PartMaterial getMaterial() {
		return material;
	}




	public void setPartMaterial(PartMaterial material) {
		this.material = material;
	}




	public PartDO( String description, double price, PartMaterial material) {
		super();
		this.description = description;
		this.price = price;
		this.material = material;
	}




	




   
}
